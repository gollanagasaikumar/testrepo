import React from 'react'
class Users extends React.Component {
  render() {
    return <h1>Users</h1>
  }
}
export default Users