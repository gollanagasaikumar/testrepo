import React, { useContext } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

 async function run() {

		axios.get('./updategamestatus.js')
       .then(res => {
        const persons = res.data;
		console.log(persons)
		//this.setState({playername : persons[0].playername.name})
        //console.log(persons[0].playername.name)
			  
	   
       })
	   
 }
run().catch(console.dir);