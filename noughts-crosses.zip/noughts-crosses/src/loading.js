import React from 'react';
import './App.css';

const Welcome = () => {
    return (<div style={{width:"100%",height:"98vh",border:"1px solid none",backgroundColor: "#F0F0F0"}}><div className =  "LoadingClass">
<img src="https://i.gifer.com/9J6b.gif" alt="Paris" style={{width:"100%",height:"100%"}}></img>
<h3>Noughts & Crosses Game Loading...</h3></div></div>)
}
export default Welcome ;