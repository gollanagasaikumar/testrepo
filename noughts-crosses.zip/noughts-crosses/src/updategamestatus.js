
const mongoose = require('mongoose');
run().catch(error => console.error(error));
                                                                                                                                   
async function run() {
	console.log(new Date(), `mongoose version: ${mongoose.version}`);
	const url = "mongodb+srv://admin:admin@noughts-crosses-zq9ru.mongodb.net/test?retryWrites=true&w=majority"
	await mongoose.connect(url, {dbName:'noughts-crosses',useNewUrlParser: true, useUnifiedTopology: true});
	const schema = new mongoose.Schema({
	gameid: String,
	playerturn: String,
	playerwon: String,
	playerone: String,
	playertwo: String,
	datetime : Date
    });
	var MyModel = mongoose.model('noughts-crosses',schema,'noughts-crosses');

	var conditions = { gameid: '123478463' },options = { multi: true };
	await MyModel.updateOne(conditions, {$set: {playerwon:"NAGA"}}, options, callback)
	function callback (err, numAffected) {

	console.log(err)
}

	
  }
  
