const { MongoClient } = require("mongodb");
 
// Replace the following with your Atlas connection string                                                                                                                                        
const url = "mongodb+srv://admin:admin@noughts-crosses-zq9ru.mongodb.net/test?retryWrites=true&w=majority";
//mongoose.connect(mongoConnectionString, {useNewUrlParser: true, useUnifiedTopology: true});

const client = new MongoClient(url,{ useUnifiedTopology: true });
 
 // The database to use
 const dbName = "noughts_crosses";
                      
 async function run() {
    try {
         await client.connect();
         console.log("Connected correctly to server");
         const db = client.db(dbName);

         // Use the collection "people"
         const col = db.collection("noughts_crosses");

         // Construct a document                                                                                                                                                              
         let gamestatistics = {
			 "playername" : {"name": "Naga"},
			 "playersteps" : {"xsteps":"12345","ysteps":"6789"},
			 "playerwon" : "O",
			 "playeremail" : "saikumar.naga@gmail.com",
			 "datetime" : new Date(),
		     "gamesstatus" : {"xplayed":0,"yplayed":1,"xlost":2,"ylost":3,"tie":4}
         }

         // Insert a single document, wait for promise so we can read it back
         const p = await col.insertOne(gamestatistics);
         // Find one document

		//await col.find({playerwon: "X"}).forEach(function(item)
		//{
		//	console.log(item.playeremail)
		//});
		
         // Print to the console
         //console.log(p.playeremail);

        } catch (err) {
         console.log(err.stack);
     }
 
     finally {
        await client.close();
    }
}

run().catch(console.dir);